package com.example.lab_02;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;
import java.util.Map;

public class MainActivity extends AppCompatActivity
{
    private TextView inputArabic;
    private TextView outputRoman;
    private EditText inputRoman;
    private TextView outputArabic;
    private StringBuilder currentNumber = new StringBuilder();
    private StringBuilder currentRoman = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputArabic = findViewById(R.id.Screen);
        outputRoman = findViewById(R.id.Result);
        inputRoman = findViewById(R.id.InputRoman);
        outputArabic = findViewById(R.id.ResultArabic);
    }

    public void onClickNumberButton(View view)
    {
        Button button = (Button) view;
        currentNumber.append(button.getText().toString());
        inputArabic.setText(currentNumber.toString());
    }

    public void onClickRomanButton(View view)
    {
        Button button = (Button) view;
        String letter = button.getText().toString();

        if (inputRoman != null)
        {
            currentRoman.append(letter);
            inputRoman.setText(currentRoman.toString());
        }
    }

    public void onClearClick(View view)
    {
        currentNumber.setLength(0);
        currentRoman.setLength(0);
        inputArabic.setText("");
        outputRoman.setText("");
        inputRoman.setText("");
        outputArabic.setText("");
    }

    public void onDeleteClick(View view)
    {
        if (currentNumber.length() > 0)
        {
            currentNumber.deleteCharAt(currentNumber.length() - 1);
            inputArabic.setText(currentNumber.toString());
        }

        if (currentRoman.length() > 0)
        {
            currentRoman.deleteCharAt(currentRoman.length() - 1);
            inputRoman.setText(currentRoman.toString());
        }
    }

    public void onConvertClick(View view)
    {
        if (currentNumber.length() > 0)
        {
            int number = Integer.parseInt(currentNumber.toString());
            if (number > 0 && number <= 3999)
            {
                outputRoman.setText(convertToRoman(number));
            }
            else
            {
                outputRoman.setText("Błąd");
            }
        }
    }

    public void onConvertRomanClick(View view)
    {
        if (inputRoman != null)
        {
            String roman = inputRoman.getText().toString().toUpperCase();
            int arabic = convertToArabic(roman);
            outputArabic.setText(arabic > 0 ? String.valueOf(arabic) : "Błąd");
        }
    }

    private String convertToRoman(int num)
    {
        String[] romanNumerals = { "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I" };
        int[] values = { 1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1 };

        StringBuilder roman = new StringBuilder();
        for (int i = 0; i < values.length; i++)
        {
            while (num >= values[i])
            {
                num -= values[i];
                roman.append(romanNumerals[i]);
            }
        }
        return roman.toString();
    }

    private int convertToArabic(String roman)
    {
        Map<Character, Integer> map = new HashMap<>();
        map.put('I', 1); map.put('V', 5); map.put('X', 10);
        map.put('L', 50); map.put('C', 100);
        map.put('D', 500); map.put('M', 1000);

        int sum = 0;
        for (int i = 0; i < roman.length(); i++)
        {
            Integer value = map.get(roman.charAt(i));

            if (value == null)
            {
                return -1;
            }

            Integer nextValue = (i < roman.length() - 1) ? map.get(roman.charAt(i + 1)) : null;

            if (nextValue != null && value < nextValue)
                sum -= value;
            else
                sum += value;
        }
        return sum;
    }
}