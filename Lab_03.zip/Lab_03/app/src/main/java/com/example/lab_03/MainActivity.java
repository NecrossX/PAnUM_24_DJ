package com.example.lab_03;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText inputPace, inputSpeed, inputDistance, inputTime;
    private TextView resultStats;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputPace = findViewById(R.id.inputPace);
        inputSpeed = findViewById(R.id.inputSpeed);
        inputDistance = findViewById(R.id.inputDistance);
        inputTime = findViewById(R.id.inputTime);
        resultStats = findViewById(R.id.resultStats);
    }

    public void calculateFromPace(View view) {
        String paceStr = inputPace.getText().toString();
        if (paceStr.isEmpty()) return;

        double pace = Double.parseDouble(paceStr);
        double speed = 60.0 / pace; // km/h

        String stats = "Prędkość: " + String.format("%.2f", speed) + " km/h\n";
        stats += "Maraton: " + formatTime(pace * 42.195) + "\n";
        stats += "Półmaraton: " + formatTime(pace * 21.0975);

        resultStats.setText(stats);
    }

    public void calculateFromSpeed(View view) {
        String speedStr = inputSpeed.getText().toString();
        if (speedStr.isEmpty()) return;

        double speed = Double.parseDouble(speedStr);
        double pace = 60.0 / speed; // min/km

        String stats = "Tempo: " + String.format("%.2f", pace) + " min/km\n";
        stats += "Maraton: " + formatTime(pace * 42.195) + "\n";
        stats += "Półmaraton: " + formatTime(pace * 21.0975);

        resultStats.setText(stats);
    }

    public void calculateFromDistanceTime(View view) {
        String distanceStr = inputDistance.getText().toString();
        String timeStr = inputTime.getText().toString();
        if (distanceStr.isEmpty() || timeStr.isEmpty()) return;

        double distance = Double.parseDouble(distanceStr);
        double time = Double.parseDouble(timeStr);
        double pace = time / distance; // min/km
        double speed = distance / (time / 60.0); // km/h

        String stats = "Tempo: " + String.format("%.2f", pace) + " min/km\n";
        stats += "Prędkość: " + String.format("%.2f", speed) + " km/h";

        resultStats.setText(stats);
    }

    private String formatTime(double minutes) {
        int h = (int) (minutes / 60);
        int m = (int) (minutes % 60);
        int s = (int) ((minutes - (h * 60 + m)) * 60);
        return h + "h " + m + "m " + s + "s";
    }
}
