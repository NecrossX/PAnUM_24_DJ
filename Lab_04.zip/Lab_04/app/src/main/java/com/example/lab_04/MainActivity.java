package com.example.lab_04;

import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Handler;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity
{
    private LinearLayout stopwatchLayout, timerLayout;
    private TextView stopwatch1, stopwatch2, timer1, timer2;
    private EditText inputTime1, inputTime2;

    private Handler handler = new Handler();
    private long time1 = 0, time2 = 0;
    private boolean running1 = false, running2 = false;

    private CountDownTimer countDownTimer1, countDownTimer2;
    private boolean timerRunning1 = false, timerRunning2 = false;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Widoki
        stopwatchLayout = findViewById(R.id.stopwatchLayout);
        timerLayout = findViewById(R.id.timerLayout);
        stopwatch1 = findViewById(R.id.stopwatch1);
        stopwatch2 = findViewById(R.id.stopwatch2);
        timer1 = findViewById(R.id.timer1);
        timer2 = findViewById(R.id.timer2);
        inputTime1 = findViewById(R.id.inputTime1);
        inputTime2 = findViewById(R.id.inputTime2);

        // Przełączanie widoku
        findViewById(R.id.buttonShowStopwatch).setOnClickListener(v -> {
            stopwatchLayout.setVisibility(View.VISIBLE);
            timerLayout.setVisibility(View.GONE);
        });

        findViewById(R.id.buttonShowTimer).setOnClickListener(v -> {
            stopwatchLayout.setVisibility(View.GONE);
            timerLayout.setVisibility(View.VISIBLE);
        });

        startStopwatchThread();
    }

    private void startStopwatchThread()
    {
        handler.postDelayed(new Runnable()
        {
            @Override
            public void run()
            {
                if (running1) time1 += 10;
                if (running2) time2 += 10;

                stopwatch1.setText(formatTime(time1));
                stopwatch2.setText(formatTime(time2));

                handler.postDelayed(this, 10);
            }
        }, 10);
    }

    private String formatTime(long time)
    {
        int millis = (int) (time % 1000) / 10;
        int seconds = (int) (time / 1000) % 60;
        int minutes = (int) (time / 60000);
        return String.format("%02d:%02d.%02d", minutes, seconds, millis);
    }

    // Stopery
    public void startStopwatch1(View v) { running1 = true; }
    public void stopStopwatch1(View v) { running1 = false; }
    public void resetStopwatch1(View v) { time1 = 0; running1 = false; }

    public void startStopwatch2(View v) { running2 = true; }
    public void stopStopwatch2(View v) { running2 = false; }
    public void resetStopwatch2(View v) { time2 = 0; running2 = false; }

    // Minutniki
    public void startTimer1(View v)
    {
        if (!timerRunning1)
        {
            long millis = Long.parseLong(inputTime1.getText().toString()) * 1000;
            countDownTimer1 = new CountDownTimer(millis, 10)
            {
                public void onTick(long millisUntilFinished)
                {
                    timer1.setText(formatTime(millisUntilFinished));
                }

                public void onFinish()
                {
                    timer1.setText("00:00.00");
                    timerRunning1 = false;
                }
            }.start();
            timerRunning1 = true;
        }
    }

    public void startTimer2(View v)
    {
        if (!timerRunning2)
        {
            long millis = Long.parseLong(inputTime2.getText().toString()) * 1000;
            countDownTimer2 = new CountDownTimer(millis, 10)
            {
                public void onTick(long millisUntilFinished)
                {
                    timer2.setText(formatTime(millisUntilFinished));
                }

                public void onFinish()
                {
                    timer2.setText("00:00.00");
                    timerRunning2 = false;
                }
            }.start();
            timerRunning2 = true;
        }
    }
}