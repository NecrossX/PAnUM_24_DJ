package com.example.lab_05;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity
{
    private ImageView itemImage;
    private TextView itemDescription;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        itemImage = findViewById(R.id.itemImage);
        itemDescription = findViewById(R.id.itemDescription);
        Button btnDrink = findViewById(R.id.btn_drink);
        Button btnSnack = findViewById(R.id.btn_snack);
        Button btnSnack2 = findViewById(R.id.btn_snack2);
        Button btnLocation = findViewById(R.id.btn_location);

        btnDrink.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                itemDescription.setText("Napój: Kawa\nCena: 12 zł");
                itemImage.setImageResource(R.drawable.kawa);
            }
        });

        btnSnack.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                itemDescription.setText("Przekąska: Ciastko\nCena: 7 zł");
                itemImage.setImageResource(R.drawable.ciastko);
            }
        });

        btnSnack2.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                itemDescription.setText("Deser: Donut\nCena: 15 zł");
                itemImage.setImageResource(R.drawable.donut);
            }
        });

        btnLocation.setOnClickListener(new View.OnClickListener()
        {
            @Override
            public void onClick(View v)
            {
                itemDescription.setText("Lokal: Kawiarnia Aroma\nAdres: ul. Kwiatowa 8, Kraków\nGodziny otwarcia: 9:00 - 21:00");
                itemImage.setImageResource(R.drawable.lokacja);
            }
        });
    }
}