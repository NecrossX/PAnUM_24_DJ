package com.example.lab_07;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity
{
    private Button[] buttons = new Button[9];
    private boolean isXTurn = true;
    private String[] board = new String[9];

    private double scoreX = 0;
    private double scoreO = 0;

    private TextView turnTextView, scoreTextView;
    private Button resetScoreButton, newGameButton;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        turnTextView = findViewById(R.id.turnTextView);
        scoreTextView = findViewById(R.id.scoreTextView);
        resetScoreButton = findViewById(R.id.resetScoreButton);
        newGameButton = findViewById(R.id.newGameButton);

        GridLayout grid = findViewById(R.id.gridLayout);

        for (int i = 0; i < 9; i++)
        {
            int index = i;
            buttons[i] = (Button) grid.getChildAt(i);
            buttons[i].setText("");
            board[i] = "";
            buttons[i].setOnClickListener(v -> handleMove(index));
        }

        resetScoreButton.setOnClickListener(v -> {
            scoreX = 0;
            scoreO = 0;
            updateScore();
            Toast.makeText(this, "Punktacja zresetowana", Toast.LENGTH_SHORT).show();
        });

        newGameButton.setOnClickListener(v -> {
            resetBoard();
            Toast.makeText(this, "Nowa runda!", Toast.LENGTH_SHORT).show();
        });

        updateScore();
    }

    private void handleMove(int index)
    {
        if (!board[index].isEmpty())
            return;

        String symbol = isXTurn ? "X" : "O";
        buttons[index].setText(symbol);
        board[index] = symbol;

        if (checkWin(symbol))
        {
            if (symbol.equals("X"))
                scoreX += 1;
            else
                scoreO += 1;

            Toast.makeText(this, "Wygrał gracz: " + symbol, Toast.LENGTH_SHORT).show();
            resetBoard();
        }
        else if (isDraw())
        {
            scoreX += 0.5;
            scoreO += 0.5;
            Toast.makeText(this, "Remis!", Toast.LENGTH_SHORT).show();
            resetBoard();
        }
        else
        {
            isXTurn = !isXTurn;
            turnTextView.setText("Tura: " + (isXTurn ? "X" : "O"));
        }

        updateScore();
    }

    private boolean checkWin(String symbol)
    {
        int[][] winPatterns = {
                {0,1,2},{3,4,5},{6,7,8}, // wiersze
                {0,3,6},{1,4,7},{2,5,8}, // kolumny
                {0,4,8},{2,4,6}          // przekątne
        };

        for (int[] pattern : winPatterns)
        {
            if (symbol.equals(board[pattern[0]]) &&
                    symbol.equals(board[pattern[1]]) &&
                    symbol.equals(board[pattern[2]]))
            {
                return true;
            }
        }

        return false;
    }

    private boolean isDraw()
    {
        for (String cell : board)
        {
            if (cell.isEmpty())
                return false;
        }
        return true;
    }

    private void resetBoard()
    {
        for (int i = 0; i < 9; i++)
        {
            board[i] = "";
            buttons[i].setText("");
        }
        isXTurn = true;
        turnTextView.setText("Tura: X");
    }

    private void updateScore()
    {
        scoreTextView.setText("X: " + scoreX + " | O: " + scoreO);
    }
}