package com.example.lab_06;

import android.os.Bundle;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import java.util.*;

public class MainActivity extends AppCompatActivity
{
    LinearLayout layoutNumbers, layoutCurrency, layoutUnits;

    EditText inputNumber, inputCurrency, inputUnit;
    TextView outputNumber, outputCurrency, outputUnit, exchangeRate;

    Spinner spinnerFromNumberSystem, spinnerToNumberSystem;
    Spinner spinnerFromCurrency, spinnerToCurrency;
    Spinner spinnerFromUnit, spinnerToUnit;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Widoki sekcji
        layoutNumbers = findViewById(R.id.layoutNumbers);
        layoutCurrency = findViewById(R.id.layoutCurrency);
        layoutUnits = findViewById(R.id.layoutUnits);

        // Przełączanie sekcji
        findViewById(R.id.btnNumbers).setOnClickListener(v -> showSection("numbers"));
        findViewById(R.id.btnCurrency).setOnClickListener(v -> showSection("currency"));
        findViewById(R.id.btnUnits).setOnClickListener(v -> showSection("units"));

        // Liczby
        inputNumber = findViewById(R.id.inputNumber);
        outputNumber = findViewById(R.id.outputNumber);
        spinnerFromNumberSystem = findViewById(R.id.spinnerFromNumberSystem);
        spinnerToNumberSystem = findViewById(R.id.spinnerToNumberSystem);

        ArrayAdapter<String> numberAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                new String[]{"Dziesiętny", "Binarny", "Ósemkowy", "Szesnastkowy", "Rzymski"});
        numberAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFromNumberSystem.setAdapter(numberAdapter);
        spinnerToNumberSystem.setAdapter(numberAdapter);

        // Waluty
        inputCurrency = findViewById(R.id.inputCurrency);
        outputCurrency = findViewById(R.id.outputCurrency);
        exchangeRate = findViewById(R.id.exchangeRate);
        spinnerFromCurrency = findViewById(R.id.spinnerFromCurrency);
        spinnerToCurrency = findViewById(R.id.spinnerToCurrency);

        ArrayAdapter<String> currencyAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                new String[]{"PLN", "USD", "EUR", "GBP", "JPY"});
        currencyAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFromCurrency.setAdapter(currencyAdapter);
        spinnerToCurrency.setAdapter(currencyAdapter);

        AdapterView.OnItemSelectedListener currencyListener = new AdapterView.OnItemSelectedListener()
        {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id)
            {
                updateExchangeRate();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {}
        };

        spinnerFromCurrency.setOnItemSelectedListener(currencyListener);
        spinnerToCurrency.setOnItemSelectedListener(currencyListener);

        // Jednostki
        inputUnit = findViewById(R.id.inputUnit);
        outputUnit = findViewById(R.id.outputUnit);
        spinnerFromUnit = findViewById(R.id.spinnerFromUnit);
        spinnerToUnit = findViewById(R.id.spinnerToUnit);

        ArrayAdapter<String> unitAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_item,
                new String[]{"mm", "cm", "m", "km", "mm²", "cm²", "m²"});
        unitAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        spinnerFromUnit.setAdapter(unitAdapter);
        spinnerToUnit.setAdapter(unitAdapter);
    }

    private void showSection(String type)
    {
        layoutNumbers.setVisibility(type.equals("numbers") ? View.VISIBLE : View.GONE);
        layoutCurrency.setVisibility(type.equals("currency") ? View.VISIBLE : View.GONE);
        layoutUnits.setVisibility(type.equals("units") ? View.VISIBLE : View.GONE);
    }

    public void convertNumber(View v)
    {
        try
        {
            String input = inputNumber.getText().toString().toUpperCase();
            String from = spinnerFromNumberSystem.getSelectedItem().toString();
            String to = spinnerToNumberSystem.getSelectedItem().toString();

            int decimal;
            if (from.equals("Dziesiętny")) decimal = Integer.parseInt(input);
            else if (from.equals("Binarny")) decimal = Integer.parseInt(input, 2);
            else if (from.equals("Ósemkowy")) decimal = Integer.parseInt(input, 8);
            else if (from.equals("Szesnastkowy")) decimal = Integer.parseInt(input, 16);
            else decimal = romanToDecimal(input);

            String result;
            if (to.equals("Dziesiętny")) result = String.valueOf(decimal);
            else if (to.equals("Binarny")) result = Integer.toBinaryString(decimal);
            else if (to.equals("Ósemkowy")) result = Integer.toOctalString(decimal);
            else if (to.equals("Szesnastkowy")) result = Integer.toHexString(decimal).toUpperCase();
            else result = decimalToRoman(decimal);

            outputNumber.setText(result);
        }
        catch (Exception e)
        {
            outputNumber.setText("Błąd danych");
        }
    }

    public void convertCurrency(View v)
    {
        try
        {
            double input = Double.parseDouble(inputCurrency.getText().toString());
            String from = spinnerFromCurrency.getSelectedItem().toString();
            String to = spinnerToCurrency.getSelectedItem().toString();

            Map<String, Double> rates = getCurrencyRates();
            double kurs = rates.get(from) / rates.get(to);

            double result = input * kurs;
            outputCurrency.setText(String.format(Locale.US, "%.2f %s", result, to));
        }
        catch (Exception e)
        {
            outputCurrency.setText("Błąd danych");
        }
    }

    private void updateExchangeRate()
    {
        try
        {
            String from = spinnerFromCurrency.getSelectedItem().toString();
            String to = spinnerToCurrency.getSelectedItem().toString();
            Map<String, Double> rates = getCurrencyRates();

            double kurs = rates.get(to) / rates.get(from);

            exchangeRate.setText(String.format(Locale.US, "Kurs: 1 %s = %.4f %s", to, kurs, from));
        }
        catch (Exception e)
        {
            exchangeRate.setText("Kurs: -");
        }
    }

    public void convertUnit(View v)
    {
        try
        {
            double input = Double.parseDouble(inputUnit.getText().toString());
            String from = spinnerFromUnit.getSelectedItem().toString();
            String to = spinnerToUnit.getSelectedItem().toString();

            Map<String, Double> units = new HashMap<>();

            // długość
            units.put("mm", 0.001);
            units.put("cm", 0.01);
            units.put("m", 1.0);
            units.put("km", 1000.0);

            // pole
            units.put("mm²", 0.000001);
            units.put("cm²", 0.0001);
            units.put("m²", 1.0);

            double result = input * (units.get(from) / units.get(to));
            outputUnit.setText(String.format(Locale.US, "%.4f %s", result, to));
        }
        catch (Exception e)
        {
            outputUnit.setText("Błąd danych");
        }
    }

    private int romanToDecimal(String roman)
    {
        Map<Character, Integer> map = new HashMap<>();
        map.put('I', 1); map.put('V', 5); map.put('X', 10);
        map.put('L', 50); map.put('C', 100);
        map.put('D', 500); map.put('M', 1000);

        int sum = 0;
        for (int i = 0; i < roman.length(); i++)
        {
            int value = map.get(roman.charAt(i));
            int next = (i + 1 < roman.length()) ? map.get(roman.charAt(i + 1)) : 0;

            if (next > value) sum -= value;
            else sum += value;
        }
        return sum;
    }

    private String decimalToRoman(int num)
    {
        String[] r = {"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"};
        int[] v = {1000,900,500,400,100,90,50,40,10,9,5,4,1};

        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < v.length; i++)
        {
            while (num >= v[i])
            {
                num -= v[i];
                sb.append(r[i]);
            }
        }
        return sb.toString();
    }

    private Map<String, Double> getCurrencyRates()
    {
        Map<String, Double> rates = new HashMap<>();
        rates.put("PLN", 1.0);
        rates.put("USD", 4.20);
        rates.put("EUR", 4.60);
        rates.put("GBP", 5.10);
        rates.put("JPY", 0.031);
        return rates;
    }
}