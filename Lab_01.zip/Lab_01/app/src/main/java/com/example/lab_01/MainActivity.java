package com.example.lab_01;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity
{
    private TextView inputArabic;
    private TextView outputRoman;
    private StringBuilder currentNumber = new StringBuilder();

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        inputArabic = findViewById(R.id.Screen);
        outputRoman = findViewById(R.id.Result);
    }

    public void onClickNumberButton(View view)
    {
        int id = view.getId();

        if (id == R.id.Button_1) currentNumber.append("1");
        else if (id == R.id.Button_2) currentNumber.append("2");
        else if (id == R.id.Button_3) currentNumber.append("3");
        else if (id == R.id.Button_4) currentNumber.append("4");
        else if (id == R.id.Button_5) currentNumber.append("5");
        else if (id == R.id.Button_6) currentNumber.append("6");
        else if (id == R.id.Button_7) currentNumber.append("7");
        else if (id == R.id.Button_8) currentNumber.append("8");
        else if (id == R.id.Button_9) currentNumber.append("9");
        else if (id == R.id.Button_0) currentNumber.append("0");

        inputArabic.setText(currentNumber.toString());
    }

    public void onClearClick(View view)
    {
        currentNumber.setLength(0);
        inputArabic.setText("");
        outputRoman.setText("");
    }

    public void onDeleteClick(View view)
    {
        if (currentNumber.length() > 0)
        {
            currentNumber.deleteCharAt(currentNumber.length() - 1);
            inputArabic.setText(currentNumber.toString());
        }
    }

    public void onConvertClick(View view)
    {
        if (currentNumber.length() > 0)
        {
            int number = Integer.parseInt(currentNumber.toString());
            if (number > 0 && number <= 3999)
            {
                outputRoman.setText(convertToRoman(number));
            }
            else
            {
                outputRoman.setText("Błąd");
            }
        }
    }

    private String convertToRoman(int num)
    {
        String[] romanNumerals = {
                "M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"
        };
        int[] values = {
                1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1
        };

        StringBuilder roman = new StringBuilder();
        for (int i = 0; i < values.length; i++)
        {
            while (num >= values[i])
            {
                num -= values[i];
                roman.append(romanNumerals[i]);
            }
        }
        return roman.toString();
    }
}